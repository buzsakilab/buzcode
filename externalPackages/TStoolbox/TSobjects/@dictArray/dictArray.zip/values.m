function v = values(O)
% dictArray/values v = values(D) returns cell array of values in dictArray D
%
% v = is a cell array

% copyright (c) 2004 Francesco P. Battaglia 
% This software is released under the GNU GPL
% www.gnu.org/copyleft/gpl.html
  
  v = O.values;
  
  
  