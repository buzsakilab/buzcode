function l = length(O)
% l = length(D) returns number of items in dictArray D
%
% just another name for len
  
% copyright (c) 2004 Francesco P. Battaglia 
% This software is released under the GNU GPL
% www.gnu.org/copyleft/gpl.html

  
  
  l = len(O);
  