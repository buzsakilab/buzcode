function n = numel(A, varargin)
  
  n = 1;